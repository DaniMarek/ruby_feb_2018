class Mammal

	def initialize
		@health = 170
	end

	def display_health
		puts "Current Health: #{@health}"
	end

end

